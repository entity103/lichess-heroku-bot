Hi guys this is the contributing.md where ill tell about the contributors of this great lichess bot repository which is a modified version of ShailChoksi and has a dockerfile to run on heroku server which most people use . SO the main contributors of this repository are:
1. [Kingnandi](https://lichess.org/@/Kingnandi) in lichess and [vigneshbot460](https://github.com/vigneshbot460) in github
2. [ChessGreatPlayer](https://lichess.org/@/ChessGreatPlayer) in lichess and [SathyaKarthik1212](https://github.com/SathyaKarthik1212) in github
3.  A  contribution account by both kingnandi and SathyaKarthik1212.
So this are contributors so enjoy and please refer this repo link to your friends and make this repository forks 100 or century that our goal to help people make lichess bots and not just simple bots but coded ones with a rating average of 2500-2600 or even more.
